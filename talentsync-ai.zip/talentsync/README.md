# TalentSync AI — Resume Screening & Job Matching Platform

An AI-powered job matching platform with two portals:
- **Recruiter** — post jobs with AI skill indexing
- **Applicant** — upload resume, get AI match scores against all jobs

---

## Quick Start

### 1. Get an Anthropic API Key
1. Visit https://console.anthropic.com/
2. Create an account and generate an API key (free tier available)

### 2. Add Your API Key
Open `js/app.js` and replace line 13:
```js
const ANTHROPIC_API_KEY = 'YOUR_API_KEY_HERE';
```
with your actual key:
```js
const ANTHROPIC_API_KEY = 'sk-ant-...your key here...';
```

### 3. Run in VS Code
**Option A — Live Server (recommended):**
1. Install the "Live Server" extension in VS Code
2. Right-click `index.html` → **Open with Live Server**
3. App opens at `http://127.0.0.1:5500`

**Option B — Python (no extension needed):**
```bash
# In this folder, run:
python -m http.server 8080
# Then open: http://localhost:8080
```

> ⚠️ **Do NOT open index.html directly** (file:// protocol).  
> The Anthropic API requires the page to be served via http:// to work.

---

## Project Structure

```
talentsync/
├── index.html        ← Main app (single page)
├── css/
│   └── style.css     ← All styles
├── js/
│   └── app.js        ← All logic + API calls
└── README.md
```

---

## Features

### Recruiter Portal
- Post job descriptions with title, company, salary, location, type
- AI auto-extracts key skills from the job description
- View and manage all posted listings
- Analyze any candidate resume vs. a job — get instant AI match score

### Applicant Portal
- Save your resume/profile
- **Job Matches** — AI scores your resume against every posted job, sorted by compatibility %
- **Explore Jobs** — browse all jobs; click "Check My Match" for a detailed breakdown
- Each match includes:
  - Overall match % (0–100)
  - 5-category breakdown (Technical Skills, Experience, Education, Industry Fit, Soft Skills)
  - AI-written actionable tips
  - Verdict: ✓ Apply Now / ⚠ Consider / ✗ Low Match

---

## Match Score Guide

| Score | Color  | Verdict            |
|-------|--------|--------------------|
| 70–100% | 🟢 Green | ✓ Apply Now      |
| 45–69%  | 🟡 Yellow | ⚠ Consider Applying |
| 0–44%   | 🔴 Red   | ✗ Low Match       |

---

## Tech Stack
- Vanilla HTML + CSS + JavaScript (no build tools required)
- Anthropic Claude API (`claude-sonnet-4-20250514`) for NLP matching
- Google Fonts (Syne + DM Sans)
