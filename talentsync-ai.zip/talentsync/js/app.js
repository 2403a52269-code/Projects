/* ═══════════════════════════════════════════════
   TalentSync AI  —  app.js
   Replace YOUR_API_KEY_HERE with your key from
   https://console.anthropic.com/
   ═══════════════════════════════════════════════ */

var API_KEY = 'YOUR_API_KEY_HERE';

/* ─── state ─── */
var S = {
  jobs: [],
  applications: [],
  resume: '', name: '', email: '', role: ''
};

/* ─── localStorage ─── */
function save() {
  localStorage.setItem('ts_jobs', JSON.stringify(S.jobs));
  localStorage.setItem('ts_apps', JSON.stringify(S.applications));
  localStorage.setItem('ts_profile', JSON.stringify({ resume:S.resume, name:S.name, email:S.email, role:S.role }));
}
function load() {
  try { S.jobs         = JSON.parse(localStorage.getItem('ts_jobs'))    || []; } catch(e) { S.jobs=[]; }
  try { S.applications = JSON.parse(localStorage.getItem('ts_apps'))    || []; } catch(e) { S.applications=[]; }
  try {
    var p = JSON.parse(localStorage.getItem('ts_profile')) || {};
    S.resume = p.resume||''; S.name = p.name||''; S.email = p.email||''; S.role = p.role||'';
  } catch(e) {}
}

/* ─── show / hide pages ─── */
function showPage(id) {
  ['pg-landing','pg-recruiter','pg-applicant'].forEach(function(p){
    document.getElementById(p).style.display = (p === id) ? 'block' : 'none';
  });
}

/* ─── enter app ─── */
function enterApp(mode) {
  if (mode === 'recruiter') {
    showPage('pg-recruiter');
    updateStats();
  } else {
    showPage('pg-applicant');
    /* pre-fill saved data */
    if (S.name)   document.getElementById('a-name').value   = S.name;
    if (S.email)  document.getElementById('a-email').value  = S.email;
    if (S.role)   document.getElementById('a-role').value   = S.role;
    if (S.resume) document.getElementById('a-resume').value = S.resume;
    if (S.resume) showSavedCard();
    renderExplore();
  }
}

function logout() { showPage('pg-landing'); }

/* ─── recruiter tabs ─── */
var R_PANELS = ['r-post','r-listings','r-applications','r-analyze'];
function rTab(name, btn) {
  R_PANELS.forEach(function(p){ document.getElementById(p).style.display = 'none'; });
  document.getElementById('r-' + name).style.display = 'block';
  document.querySelectorAll('#r-tabs .nav-tab').forEach(function(t){ t.classList.remove('active'); });
  btn.classList.add('active');
  if (name === 'listings')     renderListings();
  if (name === 'applications') renderRecruiterApps();
  if (name === 'analyze')      populateAnalyzeDropdown();
}

/* ─── applicant tabs ─── */
var A_PANELS = ['a-profile','a-matches','a-explore','a-myapps'];
function aTab(name, btn) {
  A_PANELS.forEach(function(p){ document.getElementById(p).style.display = 'none'; });
  document.getElementById('a-' + name).style.display = 'block';
  document.querySelectorAll('#a-tabs .nav-tab').forEach(function(t){ t.classList.remove('active'); });
  btn.classList.add('active');
  if (name === 'matches') renderMatches();
  if (name === 'explore') renderExplore();
  if (name === 'myapps')  renderMyApps();
}
function aTabDirect(name) {
  var btns = document.querySelectorAll('#a-tabs .nav-tab');
  var map  = ['profile','matches','explore','myapps'];
  btns.forEach(function(b,i){ b.classList.toggle('active', map[i]===name); });
  A_PANELS.forEach(function(p){ document.getElementById(p).style.display = 'none'; });
  document.getElementById('a-' + name).style.display = 'block';
  if (name === 'matches') renderMatches();
  if (name === 'explore') renderExplore();
  if (name === 'myapps')  renderMyApps();
}

/* ─── stats ─── */
function updateStats() {
  var j = document.getElementById('stat-jobs');
  var a = document.getElementById('stat-apps');
  if (j) j.textContent = S.jobs.length;
  if (a) a.textContent = S.applications.length;
}

/* ─── toast ─── */
function toast(msg) {
  var n = document.getElementById('notif');
  n.textContent = msg;
  n.classList.add('show');
  setTimeout(function(){ n.classList.remove('show'); }, 3500);
}

/* ─── score helpers ─── */
function scoreClass(s) { return s>=70?'high':s>=45?'mid':'low'; }
function scoreColor(s) { return s>=70?'var(--success)':s>=45?'var(--warn)':'var(--accent)'; }
function scoreTip(s, role) {
  if (s>=80) return 'Excellent fit for ' + role + '! Highly recommended to apply.';
  if (s>=70) return 'Good match for ' + role + '. You meet most requirements — go ahead and apply.';
  if (s>=50) return 'Moderate fit. Highlight specific skills before applying for ' + role + '.';
  if (s>=30) return 'Weak match. Consider upskilling before applying for ' + role + '.';
  return 'Not a strong match right now. Build the required skills first.';
}
function verdictLabel(s) {
  if (s>=70) return { cls:'go',    text:'✓ Strong Match' };
  if (s>=45) return { cls:'maybe', text:'⚠ Moderate Match' };
  return           { cls:'skip',  text:'✗ Low Match' };
}
function applied(jobId) {
  return S.applications.some(function(a){ return a.jobId===jobId && a.email===S.email; });
}
function fmtDate(iso) {
  return new Date(iso).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});
}

/* ═══════════════════ AI CALLS ═══════════════════ */
async function callAI(prompt, tokens) {
  tokens = tokens || 600;
  if (API_KEY === 'YOUR_API_KEY_HERE') throw new Error('no key');
  var res = await fetch('https://api.anthropic.com/v1/messages', {
    method:'POST',
    headers:{ 'Content-Type':'application/json','x-api-key':API_KEY,'anthropic-version':'2023-06-01' },
    body: JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:tokens, messages:[{role:'user',content:prompt}] })
  });
  var d = await res.json();
  if (d.error) throw new Error(d.error.message);
  return d.content.map(function(x){ return x.text||''; }).join('');
}

async function extractSkills(jd) {
  try {
    var r = await callAI('Extract 6-8 key skills from this job description. Return ONLY a JSON array of short strings, no markdown:\n\n'+jd, 300);
    return JSON.parse(r.replace(/```json|```/g,'').trim());
  } catch(e) { return ['Communication','Problem Solving','Teamwork']; }
}

async function getScore(resume, jd, title) {
  var prompt =
    'You are an HR AI. Score the match between this resume and job.\n\n'+
    'JOB TITLE: '+title+'\nJOB DESCRIPTION: '+jd+'\n\nRESUME:\n'+resume+'\n\n'+
    'Return ONLY valid JSON (no markdown):\n'+
    '{"score":<0-100>,"breakdown":['+
    '{"label":"Technical Skills","score":<0-100>},'+
    '{"label":"Experience Level","score":<0-100>},'+
    '{"label":"Education","score":<0-100>},'+
    '{"label":"Industry Fit","score":<0-100>},'+
    '{"label":"Soft Skills","score":<0-100>}'+
    '],"tips":"<2 actionable sentences for candidate>"}';
  try {
    var r = await callAI(prompt, 700);
    return JSON.parse(r.replace(/```json|```/g,'').trim());
  } catch(e) {
    var seed = (resume.length + jd.length) % 40 + 40;
    return {
      score: seed,
      breakdown:[
        {label:'Technical Skills', score:Math.min(100,seed+10)},
        {label:'Experience Level', score:Math.min(100,seed+5)},
        {label:'Education',        score:Math.min(100,seed-5)},
        {label:'Industry Fit',     score:Math.min(100,seed+15)},
        {label:'Soft Skills',      score:Math.min(100,seed+20)}
      ],
      tips:'AI tips unavailable — add your API key in js/app.js to enable full scoring.'
    };
  }
}

/* ═══════════════════ RECRUITER — POST JOB ═══════════════════ */
async function postJob() {
  var title   = document.getElementById('r-title').value.trim();
  var company = document.getElementById('r-company').value.trim();
  var jd      = document.getElementById('r-jd').value.trim();
  var loc     = document.getElementById('r-location').value.trim();
  var type    = document.getElementById('r-type').value;
  var salary  = document.getElementById('r-salary').value.trim();
  if (!title || !jd) { toast('⚠ Fill in Job Title and Description.'); return; }
  var btn = document.getElementById('btn-post-job');
  btn.disabled = true; btn.textContent = 'Indexing with AI...';
  var skills = await extractSkills(jd);
  S.jobs.push({ id:Date.now(), title:title, company:company||'Company', location:loc||'Remote',
    type:type, salary:salary, jd:jd, skills:skills, posted:new Date().toLocaleDateString('en-IN') });
  save(); updateStats();
  btn.disabled = false; btn.textContent = '✦ Post Job';
  ['r-title','r-company','r-jd','r-location','r-salary'].forEach(function(id){
    document.getElementById(id).value = '';
  });
  toast('✅ Job posted and saved!');
}

/* ═══════════════════ RECRUITER — LISTINGS ═══════════════════ */
function renderListings() {
  var c = document.getElementById('r-listings-body');
  if (!S.jobs.length) {
    c.innerHTML = '<div class="empty"><div class="ei">📋</div><h3>No jobs posted yet</h3><p>Go to Post Job to create your first listing.</p></div>';
    return;
  }
  c.innerHTML = S.jobs.map(function(j) {
    var cnt = S.applications.filter(function(a){ return a.jobId===j.id; }).length;
    return '<div class="listed-job">'+
      '<div>'+
        '<div class="lj-title">'+j.title+'</div>'+
        '<div class="lj-meta">'+j.company+' · '+j.location+' · '+j.type+' · Posted '+j.posted+'</div>'+
        '<div class="tags-row">'+j.skills.map(function(s){ return '<span class="tag">'+s+'</span>'; }).join('')+'</div>'+
      '</div>'+
      '<div style="display:flex;align-items:center;gap:12px;">'+
        '<div class="status-chip"><div class="sdot"></div>'+cnt+' applicant'+(cnt!==1?'s':'')+'</div>'+
        '<button class="btn btn-outline sm" onclick="removeJob('+j.id+')">Remove</button>'+
      '</div>'+
    '</div>';
  }).join('');
}

function removeJob(id) {
  if (!confirm('Remove this job?')) return;
  S.jobs = S.jobs.filter(function(j){ return j.id!==id; });
  S.applications = S.applications.filter(function(a){ return a.jobId!==id; });
  save(); renderListings(); updateStats();
  toast('Job removed.');
}

/* ═══════════════════ RECRUITER — APPLICATIONS ═══════════════════ */
function renderRecruiterApps() {
  var c = document.getElementById('r-apps-body');
  if (!S.applications.length) {
    c.innerHTML = '<div class="empty"><div class="ei">📨</div><h3>No applications yet</h3><p>Applications will appear here once candidates apply.</p></div>';
    return;
  }
  c.innerHTML = S.applications.map(function(a) {
    var sc = a.score; var v = verdictLabel(sc);
    return '<div class="app-card">'+
      '<div class="app-card-top">'+
        '<div>'+
          '<div class="app-cname">'+a.name+' <span class="app-email">&lt;'+a.email+'&gt;</span></div>'+
          '<div class="app-cmeta">Applied for <strong>'+a.jobTitle+'</strong> at '+a.company+' · '+fmtDate(a.appliedAt)+'</div>'+
        '</div>'+
        '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">'+
          '<div class="match-pill '+scoreClass(sc)+'">'+sc+'% Match</div>'+
          '<select class="status-sel" onchange="updateAppStatus('+a.id+',this.value)">'+
            ['Under Review','Shortlisted','Interview Scheduled','Rejected','Hired'].map(function(opt){
              return '<option'+(a.status===opt?' selected':'')+'>'+opt+'</option>';
            }).join('')+
          '</select>'+
        '</div>'+
      '</div>'+
      (a.coverLetter ? '<div class="cl-box"><div class="cl-label">Cover Letter</div>'+a.coverLetter+'</div>' : '')+
      '<div class="breakdown">'+
        a.breakdown.map(function(b){
          return '<div class="bi"><div class="bi-lbl">'+b.label+'</div>'+
            '<div class="bi-bar"><div class="bi-fill" style="width:'+b.score+'%;background:'+scoreColor(b.score)+';"></div></div>'+
            '<div class="bi-val">'+b.score+'%</div></div>';
        }).join('')+
      '</div>'+
    '</div>';
  }).join('');
}

function updateAppStatus(id, val) {
  var a = S.applications.find(function(x){ return x.id===id; });
  if (a) { a.status = val; save(); toast('Status updated to "'+val+'"'); }
}

/* ═══════════════════ RECRUITER — ANALYZE ═══════════════════ */
function populateAnalyzeDropdown() {
  var sel = document.getElementById('r-az-job');
  sel.innerHTML = S.jobs.length
    ? S.jobs.map(function(j){ return '<option value="'+j.id+'">'+j.title+' — '+j.company+'</option>'; }).join('')
    : '<option>No jobs posted yet</option>';
}

async function analyzeCandidate() {
  var jobId  = document.getElementById('r-az-job').value;
  var resume = document.getElementById('r-az-resume').value.trim();
  var job    = S.jobs.find(function(j){ return j.id==jobId; });
  if (!job || !resume) { toast('⚠ Select a job and paste a resume.'); return; }
  var btn = document.getElementById('btn-analyze');
  btn.disabled = true; btn.textContent = '🤖 Analyzing...';
  var res = document.getElementById('r-az-result');
  res.innerHTML = '<div class="card"><div class="thinking"><div class="dots"><span></span><span></span><span></span></div>Analyzing...</div></div>';
  var match = await getScore(resume, job.jd, job.title);
  btn.disabled = false; btn.textContent = '🔍 Analyze Match';
  res.innerHTML = buildMatchCard(match, job, false);
}

/* ═══════════════════ APPLICANT — PROFILE ═══════════════════ */
function saveProfile() {
  var name   = document.getElementById('a-name').value.trim();
  var email  = document.getElementById('a-email').value.trim();
  var role   = document.getElementById('a-role').value.trim();
  var resume = document.getElementById('a-resume').value.trim();
  if (!resume) { toast('⚠ Please paste your resume text.'); return; }
  if (!email)  { toast('⚠ Please enter your email address.'); return; }
  S.name = name||'Applicant'; S.email = email; S.role = role||'Professional'; S.resume = resume;
  save(); showSavedCard(); updateStats();
  toast('✅ Profile saved! Finding your matches...');
  setTimeout(function(){ aTabDirect('matches'); }, 1200);
}

function showSavedCard() {
  document.getElementById('profile-saved-card').style.display = 'block';
  document.getElementById('pv-name').textContent   = S.name;
  document.getElementById('pv-role').textContent   = S.role;
  document.getElementById('pv-resume').textContent = S.resume.substring(0,300)+(S.resume.length>300?'...':'');
}

/* ═══════════════════ APPLICANT — MATCHES ═══════════════════ */
async function renderMatches() {
  var c = document.getElementById('a-matches-body');
  if (!S.resume) {
    c.innerHTML = '<div style="padding:32px"><div class="empty"><div class="ei">📄</div><h3>Upload your resume first</h3><p>Go to My Profile, paste your resume and click Save.</p></div></div>';
    return;
  }
  if (!S.jobs.length) {
    c.innerHTML = '<div style="padding:32px"><div class="empty"><div class="ei">🔍</div><h3>No jobs available yet</h3><p>Recruiters haven\'t posted any positions yet.</p></div></div>';
    return;
  }
  c.innerHTML = '<div style="padding:32px"><div class="thinking"><div class="dots"><span></span><span></span><span></span></div>Analyzing your profile against '+S.jobs.length+' job(s)...</div></div>';
  var scored = [];
  for (var i=0; i<S.jobs.length; i++) {
    var m = await getScore(S.resume, S.jobs[i].jd, S.jobs[i].title);
    scored.push({ job:S.jobs[i], match:m });
  }
  scored.sort(function(a,b){ return b.match.score - a.match.score; });
  var strong = scored.filter(function(x){ return x.match.score>=70; }).length;
  var best   = scored.length ? scored[0].match.score : 0;
  c.innerHTML =
    '<div style="padding:32px;">'+
    '<div class="page-header"><h2>Your Job Matches</h2><p>Sorted by AI compatibility — highest first.</p></div>'+
    '<div class="rec-banner">'+
      '<div><h3>✦ '+strong+' Recommended Role'+(strong!==1?'s':'')+' Found</h3>'+
      '<p>Roles above 70% are strong matches. Click Apply Now to submit your application.</p></div>'+
      '<span class="ai-tag">NLP ENGINE</span>'+
    '</div>'+
    '<div class="stats-row">'+
      '<div class="stat-card"><div class="sv">'+scored.length+'</div><div class="sl">Analyzed</div></div>'+
      '<div class="stat-card"><div class="sv" style="color:var(--success)">'+strong+'</div><div class="sl">Strong Matches</div></div>'+
      '<div class="stat-card"><div class="sv">'+best+'%</div><div class="sl">Best Score</div></div>'+
      '<div class="stat-card"><div class="sv">'+S.applications.length+'</div><div class="sl">Applied</div></div>'+
    '</div>'+
    '<div class="jobs-grid">'+
      scored.map(function(x){ return buildJobCard(x.job, x.match); }).join('')+
    '</div></div>';
}

/* ═══════════════════ APPLICANT — EXPLORE ═══════════════════ */
function renderExplore() {
  var c = document.getElementById('a-explore-body');
  if (!S.jobs.length) {
    c.innerHTML = '<div class="empty"><div class="ei">🌐</div><h3>No jobs yet</h3><p>Recruiters haven\'t posted any positions.</p></div>';
    return;
  }
  c.innerHTML = '<div class="jobs-grid">'+
    S.jobs.map(function(j) {
      var alr = applied(j.id);
      return '<div class="job-card">'+
        '<div class="jc-top">'+
          '<div><div class="jc-title">'+j.title+'</div><div class="jc-meta">'+j.company+' · '+j.location+'</div></div>'+
          '<span class="tag">'+j.type+'</span>'+
        '</div>'+
        '<div class="tags-row">'+j.skills.slice(0,5).map(function(s){ return '<span class="tag">'+s+'</span>'; }).join('')+'</div>'+
        '<div class="jc-footer">'+
          '<div class="jc-salary">'+( j.salary||'Salary not specified')+'</div>'+
          '<div style="display:flex;gap:8px;">'+
            '<button class="btn btn-outline sm" onclick="openMatchModal('+j.id+')">🔍 Check Match</button>'+
            (alr
              ? '<button class="btn" style="background:var(--surface3);color:var(--text3);cursor:default;padding:8px 14px;font-size:13px;" disabled>✓ Applied</button>'
              : '<button class="btn btn-primary sm" onclick="openApplyModal('+j.id+')">Apply Now 🚀</button>')+
          '</div>'+
        '</div>'+
      '</div>';
    }).join('')+
  '</div>';
}

/* ═══════════════════ APPLICANT — MY APPLICATIONS ═══════════════════ */
function renderMyApps() {
  var c = document.getElementById('a-myapps-body');
  var mine = S.applications.filter(function(a){ return a.email===S.email; });
  if (!mine.length) {
    c.innerHTML = '<div class="empty"><div class="ei">📬</div><h3>No applications yet</h3><p>Apply for jobs from the Matches or Explore tabs.</p></div>';
    return;
  }
  var statusColor = { 'Under Review':'var(--text3)', 'Shortlisted':'var(--info)',
    'Interview Scheduled':'var(--warn)', 'Rejected':'var(--accent)', 'Hired':'var(--success)' };
  c.innerHTML = mine.map(function(a) {
    var sc = a.score; var col = statusColor[a.status]||'var(--text3)';
    return '<div class="app-card">'+
      '<div class="app-card-top">'+
        '<div>'+
          '<div class="app-cname">'+a.jobTitle+'</div>'+
          '<div class="app-cmeta">'+a.company+' · Applied on '+fmtDate(a.appliedAt)+'</div>'+
        '</div>'+
        '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">'+
          '<div class="match-pill '+scoreClass(sc)+'">'+sc+'% Match</div>'+
          '<div class="status-badge" style="background:'+col+'20;color:'+col+';border:1px solid '+col+'40;">'+a.status+'</div>'+
        '</div>'+
      '</div>'+
      (a.coverLetter ? '<div class="cl-box"><div class="cl-label">Your Cover Letter</div>'+a.coverLetter+'</div>' : '')+
      '<div class="breakdown">'+
        a.breakdown.map(function(b){
          return '<div class="bi"><div class="bi-lbl">'+b.label+'</div>'+
            '<div class="bi-bar"><div class="bi-fill" style="width:'+b.score+'%;background:'+scoreColor(b.score)+';"></div></div>'+
            '<div class="bi-val">'+b.score+'%</div></div>';
        }).join('')+
      '</div>'+
    '</div>';
  }).join('');
}

/* ═══════════════════ MATCH MODAL ═══════════════════ */
async function openMatchModal(jobId) {
  if (!S.resume) { toast('⚠ Save your resume in My Profile first.'); return; }
  var job = S.jobs.find(function(j){ return j.id===jobId; });
  if (!job) return;
  document.getElementById('modal-match-title').textContent = job.title+' — '+job.company;
  document.getElementById('modal-match-body').innerHTML =
    '<div class="thinking"><div class="dots"><span></span><span></span><span></span></div>Calculating your match...</div>';
  document.getElementById('modal-match').style.display = 'flex';
  var match = await getScore(S.resume, job.jd, job.title);
  document.getElementById('modal-match-body').innerHTML = buildMatchCard(match, job, true);
}
function closeMatchModal() { document.getElementById('modal-match').style.display = 'none'; }

/* ═══════════════════ APPLY MODAL ═══════════════════ */
function openApplyModal(jobId) {
  if (!S.resume || !S.email) { toast('⚠ Save your profile and email first.'); return; }
  if (applied(jobId)) { toast('ℹ You already applied for this job.'); return; }
  var job = S.jobs.find(function(j){ return j.id===jobId; });
  if (!job) return;
  document.getElementById('modal-apply-title').textContent = 'Apply: '+job.title+' at '+job.company;
  document.getElementById('modal-apply-body').innerHTML =
    '<div class="apply-info-grid">'+
      '<div class="ai-item"><div class="ai-lbl">Applying as</div><div class="ai-val">'+S.name+'</div></div>'+
      '<div class="ai-item"><div class="ai-lbl">Email</div><div class="ai-val">'+S.email+'</div></div>'+
      '<div class="ai-item"><div class="ai-lbl">Role</div><div class="ai-val">'+job.title+'</div></div>'+
      '<div class="ai-item"><div class="ai-lbl">Company</div><div class="ai-val">'+job.company+'</div></div>'+
    '</div>'+
    '<div class="fg" style="margin-top:18px;">'+
      '<label class="fl">Cover Letter <span style="color:var(--text3);font-weight:400;">(optional)</span></label>'+
      '<textarea class="fi ta" id="cover-letter" style="min-height:110px;" placeholder="Write a short note to the recruiter..."></textarea>'+
    '</div>'+
    '<div style="display:flex;gap:12px;margin-top:12px;">'+
      '<button class="btn btn-primary" style="flex:1;justify-content:center;" id="btn-submit-app" onclick="submitApp('+jobId+')">🚀 Submit Application</button>'+
      '<button class="btn btn-outline" onclick="closeApplyModal()">Cancel</button>'+
    '</div>';
  document.getElementById('modal-apply').style.display = 'flex';
}
function closeApplyModal() { document.getElementById('modal-apply').style.display = 'none'; }

async function submitApp(jobId) {
  var job = S.jobs.find(function(j){ return j.id===jobId; });
  var cl  = document.getElementById('cover-letter').value.trim();
  var btn = document.getElementById('btn-submit-app');
  btn.disabled = true; btn.textContent = '⏳ Submitting...';
  var match = await getScore(S.resume, job.jd, job.title);
  S.applications.push({
    id: Date.now(), jobId: job.id, jobTitle: job.title, company: job.company,
    name: S.name, email: S.email, role: S.role, resume: S.resume,
    coverLetter: cl, score: match.score, breakdown: match.breakdown,
    appliedAt: new Date().toISOString(), status: 'Under Review'
  });
  save(); closeApplyModal(); updateStats();
  toast('✅ Applied for "'+job.title+'"! Your score: '+match.score+'%');
  /* refresh current applicant tab */
  var active = document.querySelector('#a-tabs .nav-tab.active');
  if (active) {
    var idx   = Array.from(document.querySelectorAll('#a-tabs .nav-tab')).indexOf(active);
    var names = ['profile','matches','explore','myapps'];
    if (names[idx]==='matches') renderMatches();
    if (names[idx]==='explore') renderExplore();
  }
}

/* ═══════════════════ RENDER HELPERS ═══════════════════ */
function buildMatchCard(match, job, showApply) {
  var sc = match.score; var col = scoreColor(sc); var v = verdictLabel(sc);
  var alr = applied(job.id);
  return '<div class="card">'+
    '<div class="match-top">'+
      '<div style="text-align:center;">'+
        '<div class="big-score" style="color:'+col+';">'+sc+'%</div>'+
        '<div class="score-lbl">Match Score</div>'+
      '</div>'+
      '<div style="flex:1;min-width:150px;">'+
        '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">'+
          '<span style="font-size:14px;font-weight:500;">'+job.title+'</span>'+
          '<span class="verdict '+v.cls+'">'+v.text+'</span>'+
        '</div>'+
        '<div class="pbar"><div class="pfill" style="width:'+sc+'%;background:'+col+';"></div></div>'+
        '<div style="font-size:13px;color:var(--text2);margin-top:8px;line-height:1.6;">'+scoreTip(sc,job.title)+'</div>'+
      '</div>'+
    '</div>'+
    (match.breakdown ?
      '<div class="card-title" style="margin-top:8px;">Score Breakdown</div>'+
      '<div class="breakdown">'+
        match.breakdown.map(function(b){
          return '<div class="bi"><div class="bi-lbl">'+b.label+'</div>'+
            '<div class="bi-bar"><div class="bi-fill" style="width:'+b.score+'%;background:'+scoreColor(b.score)+';"></div></div>'+
            '<div class="bi-val">'+b.score+'%</div></div>';
        }).join('')+
      '</div>' : '')+
    (match.tips ? '<div class="ai-tips-box"><div class="ai-tips-lbl">AI Suggestions</div>'+match.tips+'</div>' : '')+
    (showApply ? (alr
      ? '<div style="margin-top:16px;text-align:center;padding:12px;background:var(--surface3);border-radius:var(--radius);color:var(--text2);font-size:14px;">✓ You have already applied for this job.</div>'
      : '<button class="btn btn-primary" style="width:100%;justify-content:center;margin-top:16px;" onclick="closeMatchModal();openApplyModal('+job.id+')">🚀 Apply Now for '+job.title+'</button>'
    ) : '')+
  '</div>';
}

function buildJobCard(job, match) {
  var sc = match.score; var col = scoreColor(sc); var v = verdictLabel(sc); var cls = scoreClass(sc);
  var alr = applied(job.id);
  var border = sc>=70?'var(--success)':sc>=45?'var(--warn)':'var(--border)';
  return '<div class="job-card" style="border-color:'+border+';">'+
    '<div class="jc-top">'+
      '<div><div class="jc-title">'+job.title+'</div><div class="jc-meta">'+job.company+' · '+job.location+' · '+job.type+'</div></div>'+
      '<div class="match-pill '+cls+'">'+sc+'%</div>'+
    '</div>'+
    '<div class="pbar"><div class="pfill" style="width:'+sc+'%;background:'+col+';"></div></div>'+
    '<div class="tags-row">'+job.skills.slice(0,5).map(function(s){ return '<span class="tag">'+s+'</span>'; }).join('')+'</div>'+
    (match.tips ? '<div class="ai-tips-box" style="margin:0;">'+match.tips+'</div>' : '')+
    '<div class="jc-footer">'+
      '<div class="jc-salary">'+(job.salary||'Salary not specified')+' · '+job.posted+'</div>'+
      '<div style="display:flex;gap:8px;align-items:center;">'+
        (alr
          ? '<span class="verdict go">✓ Applied</span><button class="btn" style="background:var(--surface3);color:var(--text3);cursor:default;padding:8px 12px;font-size:12px;" disabled>Applied</button>'
          : '<span class="verdict '+v.cls+'">'+v.text+'</span><button class="btn btn-primary sm" onclick="openApplyModal('+job.id+')">Apply Now 🚀</button>')+
        '<button class="btn btn-outline sm" onclick="openMatchModal('+job.id+')">Details</button>'+
      '</div>'+
    '</div>'+
  '</div>';
}

/* ═══════════════════ BOOT ═══════════════════ */
load();   /* restore from localStorage on every page load */
